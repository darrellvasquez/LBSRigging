import os
import sys
import pymel.core as pm

print 'In User Setup'

pm.evalDeferred('import startup')